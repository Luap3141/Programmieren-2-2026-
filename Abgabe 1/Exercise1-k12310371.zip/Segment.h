#include <cmath>
#include <stdexcept>
#include <iostream>
#include "Aux.h"

#ifndef _Segment_

#define _Segment_

class Segment {

public:
   double x0;
   double y0;
   double x1;
   double y1;

   /*
    * Self explanatory constructors...
    */
   Segment() {
   }
   Segment(double StartX, double StartY, double EndX, double EndY) {
      x0 = StartX;
      y0 = StartY;
      x1 = EndX;
      y1 = EndY;
   }

   /*
    * operator<<
    * output is of form
    * x0 y0 x1 y1
    * with:
    * (x0,y0) coordinates of starting point
    * (x1,y1) coordinates of endpoint
    * all coordinates are rounded down to nearest integer
    */
   friend std::ostream& operator<<(std::ostream &os, const Segment &s) {
      os << floor(s.x0) << " " << floor(s.y0) << " " << floor(s.x1) << " "
            << floor(s.y1);
      return os;
   }

   /*
    * length()
    * returns length of segment measured in euclidean distance
    */
   const double length();

   /*
    * run()
    * returns horizontal difference of Start and Endpoint
    */
   const double run();

   /*
   * rise()
   * returns vertical difference of Start and Endpoint
   */
   const double rise();

   /*
    * angle();
    * returns cw angle of line segment
    */
   const double angle();

   /*
    * collides(other)
    * returns true if this and other collide
    * in that case, the endpoint of this is set to the point of collision
    */
   bool collides(Segment &other);
};

const double Segment::length() {
   return std::sqrt(std::pow((x1 - x0), 2) + std::pow((y1 - y0), 2));
}

const double Segment::run() {
   return x1 - x0;
}

const double Segment::rise() {
     return y1 - y0;
  }

const double Segment::angle()  {
   return std::atan2(rise(), run());
}

bool Segment::collides(Segment &other) {
   if (angle() == other.angle()) {
      //if this happens, we don't want to break the program with an exception.
      //but we cannot calculate a unique collision point either.
      //Therefore we just pretend, that they don't colllide.
      //The odds are 0% anyway
      return false;
   }
   //Solve a + mu*b = c + lambda*d with
   //a = (x0,y0)
   //c = (other.x0,other.y0)
   //b = (run(),rise())
   //d = (other.run),other.rise())
   double det = run() * other.rise() - rise() * other.run(); //determinant of matrix
   double mu = (other.rise() * (other.x0 - x0)
         - other.run() * (other.y0 - y0)) / det;
   double lambda = (run() * (other.y0 - y0) - rise() * (other.x0 - x0))
         / det;
   if ((0 <= mu) && (mu <= 1) && (-1 <= lambda) && (lambda <= 0)) {
      x1 = x0 + mu * run();
      y1 = y0 + mu * rise();
      return true;
   }
   return false;
}

#endif
